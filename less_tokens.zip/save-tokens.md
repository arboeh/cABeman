# Token-Saving Prompts for Copilot Chat

> Based on the ideas of [JuliusBrussee/caveman](https://github.com/JuliusBrussee/caveman), adapted for VS Code GitHub Copilot Chat.  
> Core idea: use system-level prompts to constrain the LLM's output style, removing filler and redundant phrasing while keeping all technical substance, saving ~65% of output tokens.

See the repository README for the full guide, including the complete contents of each `.prompt.md` file.

## Files

All files live in the **VS Code user-level directory** (`%APPDATA%\Code\User\prompts\`, i.e. `C:\Users\{username}\AppData\Roaming\Code\User\prompts\`).

| File | Type | Purpose |
|------|------|---------|
| `caveman-lite.instructions.md` | Auto-injected | `applyTo: "**"` matches all files, so it takes effect in every Copilot chat |
| `caveman-lite.prompt.md` | On demand | 🪶 Cut fluff, keep grammar |
| `caveman-full.prompt.md` | On demand | 🪨 No articles, fragments, classic caveman style |
| `caveman-ultra.prompt.md` | On demand | 🔥 Telegraphic compression, abbreviations + arrows |
| `caveman-wenyan.prompt.md` | On demand | 📜 Classical Chinese, 80-90% character reduction |

## Setup

1. Create the directory: `mkdir "$env:APPDATA\Code\User\prompts"`
2. Copy `caveman-lite.instructions.md` into it (effective immediately).
3. Optionally copy the 4 `.prompt.md` files into the same directory.
4. Add to `.vscode/settings.json` (or user settings):

```jsonc
{
  // Enable .instructions.md / .prompt.md from the user-level prompts directory
  "chat.promptFiles": true,
  // Enable Agent Skills (allows picking .prompt.md files on demand)
  "chat.useAgentSkills": true,
  // Max requests per session in Agent mode
  "chat.agent.maxRequests": 50
}
```

## Usage

| Scenario | Action | Effect |
|----------|--------|--------|
| **Everyday (default)** | Nothing to do | `.instructions.md` auto-injects the lite level |
| **Upgrade to Full** | Type `#` in the Chat input → `Prompt...` → `caveman-full` | Current conversation switches to caveman mode |
| **Upgrade to Ultra** | Same, pick `caveman-ultra` | Telegraphic maximum compression |
| **Switch to Wenyan** | Same, pick `caveman-wenyan` | Classical Chinese output |
| **Stop** | Say "normal mode" or "stop concise" in the chat | Back to standard replies |

## Notes

1. **Do not use `github.copilot.chat.codeGeneration.instructions` in `settings.json`**: it is deprecated and produces a warning. Use `.instructions.md` files instead
2. `applyTo: "**"` matches all file types, so it applies globally and automatically
3. `.prompt.md` files are not injected automatically; reference them in Chat with `#`
4. All files live in the user-level directory and work across projects
5. Security warnings and irreversible operations automatically return to normal wording
